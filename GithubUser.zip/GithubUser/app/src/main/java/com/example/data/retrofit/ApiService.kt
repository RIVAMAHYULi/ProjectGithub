package com.example.data.retrofit

import com.example.data.response.GithubResponse
import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @Headers("Authorization: token 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")
    @GET("search/users")
    fun getUser(@Query("q") username : String): Call<GithubResponse>
}